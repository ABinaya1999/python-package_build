def my_name():
    print("Hello, I am Binay.")
    return "Hello, I am Binay."
